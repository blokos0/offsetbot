table.insert(editor_objlist_order, "bgcenter") -- (A)
table.insert(editor_objlist_order, "bgedge") -- (A)
table.insert(editor_objlist_order, "bgcorner") -- (A)

editor_objlist["bgcenter"] = 
{
	name = "bgcenter",
	sprite_in_root = false,
	unittype = "object",
	tags = {"cell-machine"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {0, 3},
}

editor_objlist["bgedge"] = 
{
	name = "bgedge",
	sprite_in_root = false,
	unittype = "object",
	tags = {"cell-machine"},
	tiling = 0,
	type = 0,
	layer = 20,
	colour = {0, 3},
}

editor_objlist["bgcorner"] = 
{
	name = "bgcorner",
	sprite_in_root = false,
	unittype = "object",
	tags = {"cell-machine"},
	tiling = 0,
	type = 0,
	layer = 20,
	colour = {0, 3},
}

formatobjlist() -- (C)